
const SUPABASE_URL = (window as any).process?.env?.SUPABASE_URL || "";
const SUPABASE_ANON_KEY = (window as any).process?.env?.SUPABASE_ANON_KEY || "";

// Helper untuk fetch dari Supabase REST API secara terus tanpa library berat
const supabaseRequest = async (path: string, options: RequestInit = {}) => {
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) return null;
  
  const headers = {
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
    'Content-Type': 'application/json',
    ...options.headers
  };

  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, { ...options, headers });
    if (!response.ok) return null;
    return await response.json();
  } catch (e) {
    return null;
  }
};

export const db = {
  // Simpan atau kemaskini user
  saveUser: async (username: string, password: string, userData: any) => {
    return await supabaseRequest('azmeer_users', {
      method: 'POST',
      headers: { 'Prefer': 'resolution=merge-duplicates' },
      body: JSON.stringify({ username, password, data: userData })
    });
  },

  // Dapatkan user
  getUser: async (username: string) => {
    const data = await supabaseRequest(`azmeer_users?username=eq.${username}&select=*`);
    return data && data.length > 0 ? data[0] : null;
  },

  // Simpan UUID video yang dijana
  saveUuid: async (userId: string, uuid: string) => {
    return await supabaseRequest('azmeer_uuids', {
      method: 'POST',
      body: JSON.stringify({ user_id: userId, uuid: uuid })
    });
  },

  // Dapatkan semua UUID milik user
  getUuids: async (userId: string) => {
    const data = await supabaseRequest(`azmeer_uuids?user_id=eq.${userId}&select=uuid`);
    return data ? data.map((d: any) => d.uuid) : [];
  },

  // Dapatkan semua user (untuk Admin)
  getAllUsers: async () => {
    const data = await supabaseRequest('azmeer_users?select=*');
    return data ? data.map((d: any) => d.data) : [];
  }
};
